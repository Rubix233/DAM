/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Figuras;

/**
 *
 * @author Andy Jan
 */
public interface FiguraGeometricaPI extends FiguraGeometrica {
    float PI = 3.1416f;
}
