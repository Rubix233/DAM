/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrador
 */
public class P1 {
    public static void main(String[] args) {
        try {
            Thread.sleep(30000);
        } catch (InterruptedException inter) {
            System.out.println("Se ha interrumpido la espera");
        }
}
}
