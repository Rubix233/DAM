
import controller.JuegoLetrasController;

public class Main {

    public static void main(String[] args) {
        JuegoLetrasController controller = new JuegoLetrasController();
        controller.iniciar();
    }
}